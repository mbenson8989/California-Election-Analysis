California county election official letters (DRAFT, for review before mailing)
Drafted for Morissa Benson, adapted from the Kansas county clerk letters (same structure and tone), rewritten for California law (California Public Records Act, Gov. Code § 7920.000 et seq.; Elections Code §§ 15360, 17301).
One letter per county, addressed to that county's elections official as listed by the Secretary of State (Registrar of Voters, County Clerk, Clerk-Recorder, or Director of Elections), in PDF and Word (.docx). Each letter contains the county's public-records (CPRA) request.
Addressees and mailing addresses: California Secretary of State, County Elections Offices, https://www.sos.ca.gov/elections/voting-resources/county-elections-offices, retrieved November 24, 2026 (America/Chicago).
Grouping: Caltrans (California Department of Transportation) district map and county chart, https://cwwp2.dot.ca.gov/documentation/district-map-county-chart.html (each of the 58 counties is in exactly one of 12 districts). The California Secretary of State does not divide the state into election regions; this grouping is only for convenience.
2026 figures in the letters are UNOFFICIAL (California SOS semi-final results, statewide as of Nov 19, 2026, 1:59 p.m. PT; counties report final results by Dec 4; SOS certifies Dec 11, 2026).
Date, signature, and sender blocks are blank on purpose. Confirm each addressee before sending. Nothing has been sent.

Counties in this file (4): Del Norte, Humboldt, Lake, Mendocino
